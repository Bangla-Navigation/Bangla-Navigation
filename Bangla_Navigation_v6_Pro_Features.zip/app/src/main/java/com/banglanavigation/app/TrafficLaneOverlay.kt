package com.banglanavigation.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class TrafficLaneOverlay(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    var trafficText: String = "Traffic: —"
    var laneText: String = "Lane: —"

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        paint.textSize = 34f
        canvas.drawText(trafficText, 24f, 44f, paint)
        paint.textSize = 30f
        canvas.drawText(laneText, 24f, 82f, paint)
    }
}
