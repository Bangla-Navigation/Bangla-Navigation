package com.banglanavigation.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class RouteResult(
    val geometry: String,
    val distanceMeters: Double,
    val durationSeconds: Double,
    val steps: List<RouteStep>
)

data class RouteStep(
    val instructionBn: String,
    val distanceMeters: Double,
    val durationSeconds: Double,
    val lanes: List<String> = emptyList(),
    val trafficSpeedKph: Double? = null,
    val trafficDelaySeconds: Double = 0.0
)

class OwnRoutingClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun route(
        fromLat: Double,
        fromLon: Double,
        toLat: Double,
        toLon: Double
    ): RouteResult? = withContext(Dispatchers.IO) {
        val url = NavigationConfig.ROUTING_BASE_URL +
                "/api/v1/route?from=$fromLat,$fromLon&to=$toLat,$toLon&steps=true&lanes=true&traffic=true"

        val request = Request.Builder().url(url).get().build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext null
            val body = response.body?.string() ?: return@withContext null
            val obj = JSONObject(body)
            val geometry = obj.optString("geometry", "")
            val distance = obj.optDouble("distance_m", 0.0)
            val duration = obj.optDouble("duration_s", 0.0)
            val arr = obj.optJSONArray("steps")
            val steps = mutableListOf<RouteStep>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    val lanes = mutableListOf<String>()
                    val la = x.optJSONArray("lanes")
                    if (la != null) for (j in 0 until la.length()) lanes.add(la.optString(j))
                    steps.add(
                        RouteStep(
                            instructionBn = x.optString("instruction_bn", "সামনে এগিয়ে যান"),
                            distanceMeters = x.optDouble("distance_m", 0.0),
                            durationSeconds = x.optDouble("duration_s", 0.0),
                            lanes = lanes,
                            trafficSpeedKph = if (x.has("traffic_speed_kph")) x.optDouble("traffic_speed_kph") else null,
                            trafficDelaySeconds = x.optDouble("traffic_delay_s", 0.0)
                        )
                    )
                }
            }
            RouteResult(geometry, distance, duration, steps)
        }
    }
}
