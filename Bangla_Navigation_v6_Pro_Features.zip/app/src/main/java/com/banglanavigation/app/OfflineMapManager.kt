package com.banglanavigation.app

import android.content.Context
import org.osmdroid.tileprovider.modules.SqliteArchiveTileWriter
import java.io.File

class OfflineMapManager(private val context: Context) {
    /**
     * Saves downloaded tiles into an MBTiles/SQLite-style archive.
     * A production app should add a visible region-download UI,
     * storage quota, Wi-Fi-only option, and provider attribution.
     */
    fun offlineDirectory(): File =
        File(context.getExternalFilesDir(null), "offline_maps").apply { mkdirs() }

    fun createTileWriter(name: String = "bangla_offline.sqlite"): SqliteArchiveTileWriter {
        return SqliteArchiveTileWriter(File(offlineDirectory(), name).absolutePath)
    }
}
