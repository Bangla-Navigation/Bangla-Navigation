package com.banglanavigation.app

import android.content.Intent

import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.*
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.*
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.util.Locale
import kotlin.math.*

data class Step(val point:GeoPoint,val type:String,val modifier:String,val distance:Double,val name:String)

class MainActivity:Activity(),LocationListener,TextToSpeech.OnInitListener{
 private lateinit var map:MapView; private lateinit var instruction:TextView; private lateinit var info:TextView; private lateinit var status:TextView
 private lateinit var lm:LocationManager; private lateinit var tts:TextToSpeech
 private val http=OkHttpClient(); private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
 private var current:GeoPoint?=null; private var destination:GeoPoint?=null; private var steps=mutableListOf<Step>()
 private var routeLine:Polyline?=null; private var destMarker:Marker?=null; private var carMarker:Marker?=null
 private var navigating=false; private var stepIndex=0; private var routeDistance=0.0; private var etaSec=0.0
 private var lastReroute=0L; private var lastVoice=0L; private var lastVoiceStep=-1
 private var currentSpeed=0.0; private var lastRoutePoint:GeoPoint?=null

 override fun onCreate(b:Bundle?){super.onCreate(b);Configuration.getInstance().userAgentValue=packageName;setContentView(R.layout.activity_main)
        startBackgroundNavigation()
  map=findViewById(R.id.map);instruction=findViewById(R.id.instruction);info=findViewById(R.id.info);status=findViewById(R.id.status)
  tts=TextToSpeech(this,this);lm=getSystemService(LOCATION_SERVICE) as LocationManager
  map.setTileSource(TileSourceFactory.MAPNIK);map.setMultiTouchControls(true);map.controller.setZoom(15.0)
  findViewById<Button>(R.id.searchButton).setOnClickListener{search(findViewById<EditText>(R.id.searchBox).text.toString())}
  findViewById<Button>(R.id.startButton).setOnClickListener{if(destination!=null){navigating=true;stepIndex=0;startGps();speak("নেভিগেশন শুরু হয়েছে")}}
  if(hasPerm())startGps()else ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),10)
 }
 private fun hasPerm()=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
 private fun startGps(){try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000L,1f,this);lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,2000L,5f,this);status.text="GPS চালু"}catch(_:Exception){}}
 private fun search(q:String){if(q.isBlank())return;status.text="গন্তব্য খোঁজা হচ্ছে..."
  scope.launch{try{val u="https://nominatim.openstreetmap.org/search?q="+java.net.URLEncoder.encode(q,"UTF-8")+"&format=json&limit=1"
   val req=Request.Builder().url(u).header("User-Agent","BanglaNavigation/4.0").build()
   val a=JSONArray(withContext(Dispatchers.IO){http.newCall(req).execute().body?.string()?:"[]"})
   if(a.length()==0){status.text="গন্তব্য পাওয়া যায়নি";return@launch}
   val o=a.getJSONObject(0);destination=GeoPoint(o.getDouble("lat"),o.getDouble("lon"))
   destMarker?.let{map.overlays.remove(it)};destMarker=Marker(map);destMarker!!.position=destination;destMarker!!.title=q;map.overlays.add(destMarker)
   current?.let{requestRoute(it,destination!!)};map.controller.animateTo(destination);map.controller.setZoom(15.0);status.text="গন্তব্য প্রস্তুত — শুরু চাপুন"
  }catch(_:Exception){status.text="নেটওয়ার্ক সমস্যা"}}
 }
 private fun requestRoute(start:GeoPoint,end:GeoPoint){scope.launch{try{
   val u="https://router.project-osrm.org/route/v1/driving/${start.longitude},${start.latitude};${end.longitude},${end.latitude}?overview=full&geometries=geojson&steps=true"
   val req=Request.Builder().url(u).build();val root=JSONObject(withContext(Dispatchers.IO){http.newCall(req).execute().body?.string()?:"{}"})
   val rt=root.getJSONArray("routes").getJSONObject(0);routeDistance=rt.getDouble("distance");etaSec=rt.getDouble("duration")
   val geom=rt.getJSONObject("geometry").getJSONArray("coordinates");routeLine?.let{map.overlays.remove(it)};routeLine=Polyline()
   for(i in 0 until geom.length()){val p=geom.getJSONArray(i);routeLine!!.addPoint(GeoPoint(p.getDouble(1),p.getDouble(0)))}
   map.overlays.add(routeLine)
   steps.clear();val legs=rt.getJSONArray("legs");for(li in 0 until legs.length()){val ss=legs.getJSONObject(li).getJSONArray("steps");for(i in 0 until ss.length()){
    val s=ss.getJSONObject(i);val m=s.getJSONObject("maneuver");val p=m.getJSONObject("location");steps.add(Step(GeoPoint(p.getDouble("lat"),p.getDouble("lon")),m.getString("type"),m.optString("modifier",""),s.getDouble("distance"),s.optString("name","")))
   }}
   stepIndex=0;map.invalidate();updateInfo();status.text="রুট আপডেট হয়েছে"
  }catch(_:Exception){status.text="রুট পাওয়া যায়নি"}}}
 override fun onLocationChanged(l:Location){current=GeoPoint(l.latitude,l.longitude);currentSpeed=if(l.hasSpeed())l.speed.toDouble() else 0.0;updateCar(l);if(navigating)navigationTick()}
 private fun updateCar(l:Location){if(carMarker==null){carMarker=Marker(map);map.overlays.add(carMarker)};carMarker!!.position=GeoPoint(l.latitude,l.longitude);carMarker!!.title="আপনার গাড়ি";carMarker!!.rotation=l.bearing;map.controller.animateTo(carMarker!!.position);map.invalidate()}
 private fun navigationTick(){
  val c=current?:return;val dToDest=distance(c,destination?:return)
  if(dToDest<25){instruction.text="আপনি গন্তব্যে পৌঁছে গেছেন";speak("আপনি গন্তব্যে পৌঁছে গেছেন");navigating=false;return}
  if(steps.isEmpty())return
  while(stepIndex<steps.size-1 && distance(c,steps[stepIndex].point)<30)stepIndex++
  val s=steps[stepIndex];val d=distance(c,s.point);instruction.text=instructionText(s,d);updateInfo()
  val now=System.currentTimeMillis()
  if(isOffRoute(c)&&now-lastReroute>15000){lastReroute=now;status.text="আপনি নির্ধারিত রাস্তা থেকে সরে গেছেন — নতুন রুট হচ্ছে";speak("আপনি রাস্তা থেকে সরে গেছেন। নতুন রুট তৈরি করছি");requestRoute(c,destination!!);return}
  if(d<160 && (stepIndex!=lastVoiceStep || now-lastVoice>12000)){speak(instructionText(s,d));lastVoice=now;lastVoiceStep=stepIndex}
 }
 private fun isOffRoute(c:GeoPoint):Boolean{val p=lastRoutePoint;return if(p==null){lastRoutePoint=c;false}else{lastRoutePoint=c;distance(c,nearestRoutePoint(c))>45}}
 private fun nearestRoutePoint(c:GeoPoint):GeoPoint{val pts=routeLine?.actualPoints?:return c;var best=c;var bd=Double.MAX_VALUE;for(p in pts){val d=distance(c,p);if(d<bd){bd=d;best=p}};return best}
 private fun instructionText(s:Step,d:Double):String="${fmt(d)} পরে ${action(s)}"+if(s.name.isNotBlank())" (${s.name})" else ""
 private fun action(s:Step)=when{
  s.type=="arrive"->"গন্তব্যে পৌঁছাবেন"
  s.modifier.contains("sharp")&&s.modifier.contains("left")->"তীব্র বাম দিকে মোড় নিন"
  s.modifier.contains("sharp")&&s.modifier.contains("right")->"তীব্র ডান দিকে মোড় নিন"
  s.modifier.contains("slight")&&s.modifier.contains("left")->"হালকা বাম দিকে যান"
  s.modifier.contains("slight")&&s.modifier.contains("right")->"হালকা ডান দিকে যান"
  s.modifier.contains("left")->"বাম দিকে মোড় নিন"
  s.modifier.contains("right")->"ডান দিকে মোড় নিন"
  s.modifier=="straight"->"সোজা চলুন"
  else->"সামনে চলুন"
 }
 private fun updateInfo(){val speedKmh=currentSpeed*3.6;info.text="অবশিষ্ট "+fmt(routeDistance)+"  •  আনুমানিক "+eta(etaSec)+"  •  গতি "+String.format(Locale.US,"%.0f কিমি/ঘণ্টা",speedKmh)}
 private fun eta(sec:Double):String{val m=(sec/60).roundToInt();return if(m<60)"$m মিনিট" else "${m/60} ঘণ্টা ${m%60} মিনিট"}
 private fun fmt(m:Double)=if(m>=1000)String.format(Locale.US,"%.1f কিমি",m/1000)else String.format(Locale.US,"%.0f মিটার",m)
 private fun distance(a:GeoPoint,b:GeoPoint):Double{val R=6371000.0;val p1=Math.toRadians(a.latitude);val p2=Math.toRadians(b.latitude);val dp=Math.toRadians(b.latitude-a.latitude);val dl=Math.toRadians(b.longitude-a.longitude);val x=sin(dp/2).pow(2)+cos(p1)*cos(p2)*sin(dl/2).pow(2);return 2*R*atan2(sqrt(x),sqrt(1-x))}
 private fun speak(s:String){if(::tts.isInitialized)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nav")}
 override fun onInit(s:Int){if(s==TextToSpeech.SUCCESS){val r=tts.setLanguage(Locale("bn","BD"));if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED)tts.language=Locale.US}}
 override fun onProviderDisabled(p:String){status.text="GPS চালু করুন"};override fun onProviderEnabled(p:String){};override fun onStatusChanged(p:String,s:Int,e:Bundle){}
 override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED)startGps()}
 override fun onDestroy(){scope.cancel();if(::tts.isInitialized){tts.stop();tts.shutdown()};try{lm.removeUpdates(this)}catch(_:Exception){};super.onDestroy()}

    private var satelliteEnabled = false

    private fun setupSatelliteToggle() {
        val btn = Button(this).apply {
            text = "স্যাটেলাইট"
            textSize = 12f
            setPadding(14, 6, 14, 6)
            setOnClickListener { toggleSatellite() }
        }
        val root = findViewById<ViewGroup>(android.R.id.content)
        root.addView(btn, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        btn.translationX = 16f
        btn.translationY = 190f
    }

    private fun toggleSatellite() {
        satelliteEnabled = !satelliteEnabled
        val source = if (satelliteEnabled) {
            object : org.osmdroid.tileprovider.tilesource.XYTileSource(
                "EsriWorldImagery", 0, 19, 256, ".jpg",
                arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/")
            ) {}
        } else {
            org.osmdroid.tileprovider.tilesource.TileSourceFactory.MAPNIK
        }
        map.setTileSource(source)
        map.invalidate()
        Toast.makeText(
            this,
            if (satelliteEnabled) "স্যাটেলাইট ভিউ চালু" else "সাধারণ ম্যাপ চালু",
            Toast.LENGTH_SHORT
        ).show()
    }


    private fun startBackgroundNavigation() {
        if (!NavigationConfig.ENABLE_BACKGROUND_NAVIGATION) return
        val intent = Intent(this, NavigationForegroundService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopBackgroundNavigation() {
        stopService(Intent(this, NavigationForegroundService::class.java))
    }

}
