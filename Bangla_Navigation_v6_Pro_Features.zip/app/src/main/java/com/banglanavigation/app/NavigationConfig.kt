package com.banglanavigation.app

object NavigationConfig {
    // Change this to your own routing server.
    // Example: https://routing.example.com
    const val ROUTING_BASE_URL = "https://YOUR-ROUTING-SERVER.example.com"

    // Your backend can return live traffic speed/flow and incidents.
    const val TRAFFIC_URL = "$ROUTING_BASE_URL/api/v1/traffic"

    // Optional: tile package / tile server for offline maps.
    const val OFFLINE_TILE_URL = "https://YOUR-TILE-SERVER.example.com/tiles/{z}/{x}/{y}.png"

    // Feature flags
    const val ENABLE_TRAFFIC = true
    const val ENABLE_LANE_GUIDANCE = true
    const val ENABLE_BACKGROUND_NAVIGATION = true
    const val ENABLE_OFFLINE_MAPS = true
    const val ENABLE_OWN_ROUTING_SERVER = true
}
