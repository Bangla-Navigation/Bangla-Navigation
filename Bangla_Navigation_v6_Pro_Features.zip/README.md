# Bangla Navigation v4 — More Realistic Navigation MVP

এই ভার্সনে যোগ করা হয়েছে:
- লাইভ GPS tracking
- গাড়ির অবস্থান ও bearing
- route line
- turn-by-turn maneuver steps
- 160m আগে বাংলা voice warning
- মোড়ের কাছে voice instruction
- গন্তব্যে পৌঁছানোর ঘোষণা
- আনুমানিক ETA
- বর্তমান গতি
- ভুল রাস্তায় গেলে off-route detection
- প্রায় 15 সেকেন্ডের cooldown রেখে automatic rerouting
- বাংলা instruction + রাস্তার নাম

গুরুত্বপূর্ণ:
এটি একটি realistic MVP, commercial navigation platform নয়। Production-এ background foreground-service navigation, robust map matching, road restrictions, traffic, lane guidance, offline maps, better rerouting, নিজের routing/geocoding backend এবং usage limits/attribution ব্যবস্থা দরকার।


## v5
Satellite/Normal map toggle added. See README_V5_SATELLITE.md.
