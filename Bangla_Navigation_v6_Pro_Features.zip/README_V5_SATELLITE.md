# Bangla Navigation v5 — Satellite View

এই ভার্সনে Normal Map / Satellite View toggle যোগ করা হয়েছে।

## কীভাবে ব্যবহার করবেন
1. Android Studio-তে project খুলুন।
2. Gradle sync করুন।
3. ফোনে Run করুন।
4. ম্যাপের উপরে **স্যাটেলাইট** বোতাম চাপলে satellite imagery এবং আবার চাপলে normal map হবে।

## গুরুত্বপূর্ণ
Satellite imagery একটি external imagery tile provider থেকে আসে। Production/commercial release করার আগে provider-এর বর্তমান terms, attribution এবং usage limits যাচাই করে নিজের অনুমোদিত provider/API key ব্যবহার করুন।

এই build-টি navigation MVP হিসেবে দেওয়া হয়েছে; production release-এর আগে নিজের routing/geocoding backend, traffic, offline maps, foreground navigation service, privacy policy এবং attribution যোগ করা উচিত।
