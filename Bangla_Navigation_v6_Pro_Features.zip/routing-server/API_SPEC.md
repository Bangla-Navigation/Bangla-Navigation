# Bangla Navigation — Own Routing Server API

The Android app expects:

GET `/api/v1/route?from=LAT,LON&to=LAT,LON&steps=true&lanes=true&traffic=true`

Response:
```json
{
  "geometry": "encoded-or-provider-defined-geometry",
  "distance_m": 12450,
  "duration_s": 1040,
  "steps": [
    {
      "instruction_bn": "ডান দিকে মোড় নিন",
      "distance_m": 180,
      "duration_s": 30,
      "lanes": ["left", "through", "right"],
      "traffic_speed_kph": 34,
      "traffic_delay_s": 45
    }
  ]
}
```

## Recommended production stack
- Routing engine: OSRM, GraphHopper, or Valhalla running on your own server.
- Map data: OpenStreetMap extracts.
- Traffic: your own traffic feed/provider; routing engine combines live speed/incidents.
- Backend: HTTPS + authentication + rate limiting.
- Never hard-code private API keys in the Android APK.
