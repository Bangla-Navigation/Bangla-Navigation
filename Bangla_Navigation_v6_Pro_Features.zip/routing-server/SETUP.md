# Own routing server starter

1. Download an OpenStreetMap `.osm.pbf` extract for your target country/region.
2. Prepare it with the OSRM preprocessing tools for the selected profile.
3. Put the generated `.osrm*` files under `routing-server/data/`.
4. Start the container with Docker Compose.
5. Put an HTTPS API gateway in front of it and implement `/api/v1/route`.
6. Set `ROUTING_BASE_URL` in `NavigationConfig.kt` to your HTTPS API.

Traffic and lane guidance are not automatically created by OSRM alone; your backend must expose current traffic/lane data or use a routing engine/provider that supports those inputs.
