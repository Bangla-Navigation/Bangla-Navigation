# Bangla Navigation v6 — Pro Navigation Foundation

Added:
- Traffic data fields in route response
- Lane guidance fields
- Foreground/background navigation service
- Offline map storage manager foundation
- Own routing server client
- Routing server API specification + OSRM starter
- Feature flags in NavigationConfig.kt

Important:
This is a production-oriented foundation, not a claim that live traffic/offline maps are magically available without data sources.
You must connect a real traffic feed, prepare offline map packages, deploy your own routing server, and comply with map/traffic data licenses.

Private API keys should stay on your backend, not inside the APK.
